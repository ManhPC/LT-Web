package tacos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TacoCloudFrontendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TacoCloudFrontendApplication.class, args);
	}

}
